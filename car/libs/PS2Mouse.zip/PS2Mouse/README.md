# PS2Mouse
A simple PS/2 Mouse Library for Arduino.

This library is accompanied by an article on Instructables: [https://www.instructables.com/id/Optical-Mouse-Odometer-for-Arduino-Robot/](https://www.instructables.com/id/Optical-Mouse-Odometer-for-Arduino-Robot/)
